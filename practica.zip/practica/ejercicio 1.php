<html>
<head></head>
<style>
</style>
<body>
<?php 
$ancho=trim(strip_tags($_REQUEST['ancho']));
$alto=trim(strip_tags($_REQUEST['alto']));
print "<h2>Altura: $alto </h2>";
print "<h2>Ancho: $ancho </h2>";
if (is_numeric($ancho))
{
	if (is_numeric($alto))
	{
		for ($i = 0; $i < $alto; $i++) 
		{  
			for ($j = 0; $j < $ancho; $j++) 
			{
				echo "*";
			}
			echo "<br>";
		}
	}
	else
	{
		echo "No es un numero en el campo de Ancho";
	}
}
else
{
	echo "Escribe un numero en el campo ancho";
}
?>
</body>
</html>