<?php
$nombre = trim(strip_tags($_REQUEST["nombre"] ?? ""));
$telefono = trim(strip_tags($_REQUEST["telefono"] ?? ""));
$matricula = isset($_REQUEST["matriculado"]) ? "matriculado" : "no matriculado";
$estudios = isset($_REQUEST["estudios"]) ? $_REQUEST["estudios"] : "";
$mostrar = $_REQUEST["datos"] ?? "";
	if (empty($nombre))
	{
		echo "El campo nombre esta vacio";
	}
		
	if (strlen($nombre)<3)
    {
        echo "Tienes que escribir mas de 3 caracteres";
    }
	
    if (empty($telefono)) 
    {
        echo "El campo telefono esta vacio";
    }
	
    if (!is_numeric($telefono))
    {
        echo "Solo se permite numeros en el campo telefono";
    }
	
    if (strlen($telefono)<9)
    {
        echo "Escribe 9 digitos";
    }
	
    if (empty($estudios))
    {
        echo "Espesifique el nivel de estudio enseñanza";
    } 
	
else
{
    if ($mostrar == "Por Pantalla")
    {
        echo "El alumno <b>$nombre</b>, con teléfono <b>$telefono, está $matricula en $estudios</b>";
    }
    if ($mostrar == "En Archivo datos.txt")
    {
        $fichero = "datos.txt";
        $mensaje = "El alumno $nombre, con teléfono $telefono, está $matricula en $estudios". PHP_EOL;
        $fd = fopen($fichero, "a");
        fwrite($fd, $mensaje);
        fclose($fd);
                echo "Datos escrito correctamente en el fichero datos.txt";
    } 
	
}
?>