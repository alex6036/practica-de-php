<?php
$fichero = "agenda.txt";
if (isset($_REQUEST["Guardar"])) 
{
    $nombre = trim(strip_tags($_REQUEST["nombre"] ?? ""));
    $trabajo = trim(strip_tags($_REQUEST["trabajo"] ?? ""));
    $telefono = trim(strip_tags($_REQUEST["telefono"] ?? ""));
    $direccion = trim(strip_tags($_REQUEST["direccion"] ?? ""));
    $otras = trim(strip_tags($_REQUEST["otras"] ?? ""));

    if (empty($nombre))
    {
        echo "El campo nombre esta vacio";
    }
	
   if (strlen($nombre) < 3)
    {
        echo "Tienes que escribir mas de 3 caracteres";
    } 
	
    if (empty($trabajo)) 
    {
        echo "El campo trabajo esta vacio";
    } 
	
    if (empty($telefono))
    {
        echo "El campo telefono esta vacio";
    }
	
    if (!is_numeric($telefono))
    {
        echo "Solo se permite numeros en el campo telefono";
    }
	
    if (strlen($telefono) < 9)
    {
        echo "Escribe 9 digitos";
    } 
	
	else 
        {
            $archivo = fopen($fichero, "a");
            fwrite($archivo, "Contacto: $nombre $trabajo $telefono $direccion $otras" . PHP_EOL);
            fclose($archivo);
        }
}

if (isset($_REQUEST["Mostrar"]))
{
    $fila = file_get_contents($fichero);
    echo "<pre>$fila</pre>";
}

if (isset($_REQUEST["Buscar_contacto"]))
{
    $buscar = trim(strip_tags($_REQUEST["Buscar"]));
    $file = fopen($fichero, "r");
    $encontrado = false;
        while(!feof($file))
        {
            $linea = fgets($file);
        
            if (strpos($linea, "Contacto: $buscar") !== false)
            {
                echo "Contacto encontrado<br>";
                echo $linea. "<br><br>";
                $encontrado = true;
            }
        }
        fclose($file);
        if (!$encontrado)
        {
            echo "El contacto $buscar no se encuentra agendado";
        }
}
?>