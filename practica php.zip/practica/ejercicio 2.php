<html>
<head></head>
<style>

</style>
<body>

<?php
	$num1=0;
	$num2=0;
	print "<h1>Jugador 1 </h1>";
	for ($i=0;$i<5;$i++)
	{
		$dado=rand(1,6);
		$num1=$num1+$dado;
		print "<img src='./img/$dado.jpg' width=100 height=100>\n";
		
	} //Fin del bucle
	print "<h1>Jugador 2 </h1>";
	for ($i=0;$i<5;$i++)
	{
		$dado=rand(1,6);
		$num2=$num2+$dado;
		print "<img src='./img/$dado.jpg' width=100 height=100>\n";
		
	} //Fin del bucle

	print "<h2>Resultado</h2>";
	if($num1>$num2)
	{
		print"<h3>El ganador es el jugador 1</h3>";
	}
	else
	{
		print"<h3>El ganador es el jugador 2</h3>";
	}

?>

</body>
</html>